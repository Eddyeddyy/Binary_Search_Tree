#include <iostream>
#include <time.h>
#include <string>
#include <vector>
#include <fstream>

#include "CSVparser.hpp"

using namespace std;

// defines a structure to hold course information
struct Course {
    string courseId; // unique identifier for course ID
    string courseName; // unique identifier for course Name
    vector<string> preReqs; // unique identifier for first prerequisite

};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a course
    Node(Course aCourse) :
        Node() {
        course = aCourse;
    }
};

//intialization of all class members
class BinarySearchTree {

private:
    Node* root;
    void addNode(Node* node, Course course);
    void addNodeAlph(Node* node, Course course);
    void storeTree(Node* node, vector<Course>& vec, int& i);
    void printAll(Node* node);
    void deleteTree(Node* node);
    int size(Node* node);
    

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void Insert(Course course);
    void InsertAlph(Course course);
    void TreeSort(vector<Course>& vec);
    void TreeSortAlph(vector<Course>& vec);
    void PrintAll();
    void DeleteTree();
    int Size();
    Course Search(string courseId);
};

//constructor for forming new bst
BinarySearchTree::BinarySearchTree() {
    //root is equal to nullptr
    root = nullptr;
}

//deconstructor for removing bst
BinarySearchTree::~BinarySearchTree() {
    //deletes the entire tree recursivley
    DeleteTree();
}

void BinarySearchTree::Insert(Course course) {
    // if root equarl to null ptr
    if (root == nullptr) {
        // root is equal to new node bid
        root = new Node(course);
        root->left = nullptr;
        root->right = nullptr;
    }
    // else
    else {
        // calls for function to add Node root and bid based on course ID
        addNode(root, course);
    }
}

void BinarySearchTree::InsertAlph(Course course) {

    // if root equarl to null ptr
    if (root == nullptr) {
        // root is equal to new node bid
        root = new Node(course);
        root->left = nullptr;
        root->right = nullptr;
    }
    // else
    else {
        // call function to add Node root and bid based on course name
        addNodeAlph(root, course);
    }
}

//function to sort tree based on course ID
void BinarySearchTree::TreeSort(vector<Course>& vec) {
    int i = 0;
    //call function to store current tree into a vector
    storeTree(root, vec, i);
    //call function to delete current tree
    DeleteTree();
    //for each course in vector, add to now empty tree based on course id
    for (int j = 0; j < vec.size(); j++) {
        Insert(vec.at(j));
    }
}

//function to sort tree based on course Name
void BinarySearchTree::TreeSortAlph(vector<Course>& vec) {
    int i = 0;
    //call function to store current tree into a vector
    storeTree(root, vec, i);
    //call function to delete current tree
    DeleteTree();
    //for each course in vector, add course into bst based on Name
    for (int j = 0; j < vec.size(); j++) {
        InsertAlph(vec.at(j));
    }
}

void BinarySearchTree::PrintAll() {
    // calls printAll function with root of tree
    printAll(root);
}

void BinarySearchTree::DeleteTree() {
    //call function to delet tree with root of tree
    deleteTree(root);
    //after every node is deleted set root to null
    root = nullptr;
}

int BinarySearchTree::Size() {
    //calls function to return size of tree
    return size(root);
}

//function to search for node based on course ID
Course BinarySearchTree::Search(string courseId) {
    Course course;
    // set current node equal to root
    Node* current = root;

    // keep looping downwards until bottom reached or matching bidId found
    while (current != nullptr) {
        if (courseId == current->course.courseId) {
            // if match found, return current bid
            return current->course;
        }
        // if bid is smaller than current node then traverse left
        else if (courseId < current->course.courseId) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
    }
    //return bid
    return course;
}

//this function adds nodes to the tree based on course ID
void BinarySearchTree::addNode(Node* node, Course course) {
    Node* current = root;
    Node* temp = new Node(course);
    while (current != nullptr) {
        // if node is larger then add to left
        if (course.courseId < current->course.courseId) {
            // if no left node
            if (current->left == nullptr) {
                // this node becomes left
                current->left = temp;
                current = nullptr;
            }
            // else recurse down the left node
            else {
                current = current->left;
            }
        }
        // else
        else {
            // if no right node
            if (current->right == nullptr) {
                // this node becomes right
                current->right = temp;
                current = nullptr;
            }
            //else
            else {
                // recurse down the right node
                current = current->right;
            }
        }
    }
    temp->left = nullptr;
    temp->right = nullptr;
}

//this function adds nodes to the tree based on course name
void BinarySearchTree::addNodeAlph(Node* node, Course course) {
    Node* current = root;
    Node* temp = new Node(course);
    while (current != nullptr) {
        // if node is larger then add to left
        if (course.courseName < current->course.courseName) {
            // if no left node
            if (current->left == nullptr) {
                // this node becomes left
                current->left = temp;
                current = nullptr;
            }
            // else recurse down the left node
            else {
                current = current->left;
            }
        }
        // else
        else {
            // if no right node
            if (current->right == nullptr) {
                // this node becomes right
                current->right = temp;
                current = nullptr;
            }
            //else
            else {
                // recurse down the right node
                current = current->right;
            }
        }
    }
    temp->left = nullptr;
    temp->right = nullptr;
}

//function to store the current tree into a vecotor
void BinarySearchTree::storeTree(Node* node, vector<Course>& vec, int& i) {
    //of node is empty return
    if (node == nullptr) {
        return;
    }
    //else find next node to the left
    storeTree(node->left, vec, i);
    //course found gets stored in vector
    vec.at(i++) = node->course;
    //find next node to the right
    storeTree(node->right, vec, i);
}

//prints all of the currents trees nodes in order
void BinarySearchTree::printAll(Node* node) {
    //if node is not equal to null ptr
    if (node == nullptr) {
        return;
    }
    //print all left
    printAll(node->left);
    //output course ID, Name, and, if any, prerequisites 
    cout << node->course.courseId << ": " << node->course.courseName;
    cout << endl;
    //print all right
    printAll(node->right);

}

//function to delete entire tree
void BinarySearchTree::deleteTree(Node* node) {
    //if node is empty return
    if (node == nullptr) {
        return;
    }
    //else call for node left child
    deleteTree(node->left);
    //then call for node right child
    deleteTree(node->right);
    //delet node
    delete node;
}

//function to return to size of the current tree
int BinarySearchTree::size(Node* node) {
    //if node is empty return value 0
    if (node == nullptr) {
        return 0;
    }
    //add 1 for root node and the values return of children
    return 1 + size(node->left) + size(node->right);
}

//local function to test for file existence
bool fileTest(const string& name) {
    ifstream f(name.c_str());
    return f.good();
}

//local function to load courses
void loadCourses(string csvPath, BinarySearchTree* bst) {
    //check to make sure file exist by calling function to test file
    if (fileTest(csvPath) == true) {
        cout << endl << "Loading CSV file " << csvPath << endl;

        // initialize the CSV Parser using the given path
        csv::Parser file = csv::Parser(csvPath);

        // read and display header row - optional
        vector<string> header = file.getHeader();
        for (auto const& c : header) {
            cout << c << " | ";
        }
        cout << "" << endl;

        try {
            // loop to read rows of a CSV file
            for (unsigned int i = 0; i < file.rowCount(); i++) {

                // Create a data structure and add to the collection of courses
                Course course;
                course.courseId = file[i][0];
                course.courseName = file[i][1];
                for (unsigned int j = 2; j < file.columnCount(); ++j) {
                    course.preReqs.push_back(file[i][j]);
                }


                // push this course to the end
                bst->Insert(course);
            }
        }
        catch (csv::Error& e) {
            std::cerr << e.what() << std::endl;
        }
    }
    //if file does not exist
    else {
        cout << endl << "File " << csvPath << " could not be found." << endl;
        cout << "No courses were loaded" << endl;
    }
    
}

int main(int argc, char* argv[]) {
    // Define a timer variable
    string courseKey;
    clock_t ticks;

    // Defined a binary search tree to hold all courses based on course ID
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    //initialize course
    Course course;
    //initialize vector for storing courses
    vector<Course> tempTree;
    //initialize string for file name
    string courseFile;

    int choice = 0;
    while (choice != 9) {
        system("CLS");
        int i = 0;
        //menu layout
        cout << "Menu:" << endl;
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List by Course ID" << endl;
        cout << "  3. Print Course List by Name" << endl;
        cout << "  4. Print Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        //input confirmation
        if (choice == 1 || choice == 2 || choice == 3) {
            switch (choice) {

            case 1:
                //display message for file name input
                cout << endl << "Please input .csv file name where course information is held: " << endl;
                //store input for file name
                cin >> courseFile;
                //adds .csv to end of file name 
                courseFile = courseFile + ".csv";
                // Initialize a timer variable before loading courses
                ticks = clock();

                //calls both methods to create two binary trees one based on course id and the other by course name
                loadCourses(courseFile, bst);

                // Calculate elapsed time and display result
                ticks = clock() - ticks; // current clock ticks minus starting clock ticks
                cout << endl << "time: " << ticks << " clock ticks" << endl;
                cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                system("PAUSE");
                break;

            case 2:
                //call function to set vector size based on bst size
                tempTree.resize(bst->Size());
                //call function to sort tree based on Name
                bst->TreeSort(tempTree);
                //if there is a bst
                if (bst->Size() != 0) {
                    cout << endl << "Here is the list of Courses organized by Course ID:" << endl << endl;
                    //call function to print all courses in order
                    bst->PrintAll();
                    cout << endl;
                    system("PAUSE");
                    break;
                }
                //else if there is no bst
                else {
                    cout << endl << "Currently there are no courses loaded." << endl;
                    cout << "Please selection option 1 from menu to load courses." << endl << endl;
                    system("PAUSE");
                    break;
                }
                

            case 3:                 
                //call function to set vector size based on bst size
                tempTree.resize(bst->Size());
                //call function to sort tree based on Name
                bst->TreeSortAlph(tempTree);
                //if there is a bst
                if (bst->Size() != 0) {
                    cout << endl << "Here is the list of Courses organized by Course Name:" << endl << endl;
                    //call function to print all courses in order
                    bst->PrintAll();
                    cout << endl;
                    system("PAUSE");
                    break;
                }
                //else if there is no bst
                else {
                    cout << endl << "Currently there are no courses loaded." << endl;
                    cout << "Please selection option 1 from menu to load courses." << endl << endl;
                    system("PAUSE");
                    break;
                }
            case 4:
                //check if bst exists
                if (bst->Size() != 0) {
                    //prompt user for course ID
                    cout << endl << "Please enter Course ID you want to know about: " << endl;
                    //input courseId as course Key
                    cin >> courseKey;
                    //call function to resize vector based on tree size
                    tempTree.resize(bst->Size());
                    //call function to sort tree based on course ID
                    bst->TreeSort(tempTree);

                    ticks = clock();

                    //calls function to search for course based on course ID.
                    course = bst->Search(courseKey);

                    ticks = clock() - ticks; // current clock ticks minus starting clock ticks
                    //prints out course information
                    if (!course.courseId.empty()) {
                        cout << endl << course.courseId << ", " << course.courseName << endl;
                        //check for prerequisites
                        if (course.preReqs.at(0) != "") {
                            cout << "Prerequisites: ";
                            for (int i = 0; i < course.preReqs.size(); ++i) {
                                if (course.preReqs.at(i) != "")
                                    cout << course.preReqs.at(i) << " | ";
                            }
                            cout << endl;
                        }
                        cout << endl;
                    }
                    //if no course ID match
                    else {
                        cout << "Course Id " << courseKey << " not found." << endl;
                    }

                    cout << "time: " << ticks << " clock ticks" << endl;
                    cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

                    system("PAUSE");
                    break;
                }
                //else if bst is empty
                else {
                    cout << endl << "Currently there are no courses loaded." << endl;
                    cout << "Please selection option 1 from menu to load courses." << endl << endl;
                    system("PAUSE");
                    break;
                }
            }
        }
        //invalid input confirmation
        else {
            cout << endl << "Invalid input. Please input a number from the menu." << endl;
            system("PAUSE");
        }
        }

    cout << endl << "Thank you for using the Course Program. Thank you." << endl;
    system("PAUSE");

    return 0;
}